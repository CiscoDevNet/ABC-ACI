'''Implementation for Pim modify triggers'''

# Genie Libs
from genie.libs.sdk.triggers.modify.modify import TriggerModify


class TriggerModifyPimNeighborFilter(TriggerModify):
	pass
