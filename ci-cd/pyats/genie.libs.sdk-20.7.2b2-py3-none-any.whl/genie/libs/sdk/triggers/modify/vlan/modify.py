'''Implementation for vlan modify triggers'''

from genie.libs.sdk.triggers.modify.modify import TriggerModify
