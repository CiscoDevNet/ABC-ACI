'''Implementation for spanning tree modify triggers'''

# import genie.libs
from genie.libs.sdk.triggers.modify.modify import TriggerModify


class TriggerModifyPvstDesgToRoot(TriggerModify):
    pass


class TriggerModifyRapidPvstDesgToRoot(TriggerModifyPvstDesgToRoot):
    pass