'''Implementation for Dot1x modify triggers'''

# import genie.libs
from genie.libs.sdk.triggers.modify.modify import TriggerModify

class TriggerModifyDot1xUserCredential(TriggerModify):
    pass