'''Implementation for vxlan  modify triggers'''

# import genie.libs
from genie.libs.sdk.triggers.modify.modify import TriggerModify