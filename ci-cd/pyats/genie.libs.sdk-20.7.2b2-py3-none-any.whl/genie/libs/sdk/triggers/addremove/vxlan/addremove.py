'''Implementation for vxlan addremove triggers'''

# Genie Libs
from genie.libs.sdk.triggers.addremove.addremove import TriggerAddRemove

