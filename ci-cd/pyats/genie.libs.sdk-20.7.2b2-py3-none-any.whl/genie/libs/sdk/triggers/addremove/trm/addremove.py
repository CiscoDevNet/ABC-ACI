'''Implementation for vxlan addremove triggers'''

