# There is no need for the write_erase_reload_device_without_reconfig api
# since we have commit replace on xr.
